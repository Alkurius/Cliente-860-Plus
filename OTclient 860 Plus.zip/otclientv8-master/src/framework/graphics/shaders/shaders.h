#ifndef SHADERS_H
#define SHADERS_H

#include "newshader.h"
#include "shadersources.h"

#endif