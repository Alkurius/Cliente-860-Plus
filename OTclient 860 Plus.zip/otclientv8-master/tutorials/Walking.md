# OTClientV8 New walking

## Check out: https://github.com/OTCv8/otclientv8-tfs