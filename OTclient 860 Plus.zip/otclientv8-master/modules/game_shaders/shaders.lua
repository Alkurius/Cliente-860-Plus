function init()
  -- add manually your shaders from /data/shaders
  g_shaders.createOutfitShader("default", "/shaders/outfit_default_vertex", "/shaders/outfit_default_fragment")
end

function terminate()
end


